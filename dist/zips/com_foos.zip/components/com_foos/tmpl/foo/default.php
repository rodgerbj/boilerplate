<?php 
echo $this->Item->name;
