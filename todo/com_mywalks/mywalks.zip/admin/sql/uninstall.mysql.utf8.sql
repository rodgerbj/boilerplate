-- best to drop tables manually in case data is lost
DROP TABLE IF EXISTS `#__mywalks`;
DROP TABLE IF EXISTS `#__mywalk_dates`;

