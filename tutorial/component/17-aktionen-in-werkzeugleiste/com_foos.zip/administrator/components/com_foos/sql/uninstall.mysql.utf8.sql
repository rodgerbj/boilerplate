DROP TABLE IF EXISTS `#__foos_details`;
