<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_foos
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Foos\Administrator\Service\Html;

defined('JPATH_BASE') or die;

/**
 * Foo HTML class.
 *
 * @since  1.0
 */
class Foo
{
}
